package org.zeroturnaround.jf.homework1;

import org.apache.commons.lang3.StringUtils;

public class Homework {

    public String reverse(String str) {
        return StringUtils.reverse(str);
    }

    /**
     * This method returns a common suffix for two strings.
     *
     * For example - given the arguments "firstString" and "secondString" the
     * method should return "String" as this is the common suffix for both.
     *
     * Another example - given the arguments "secondString" and "thirdString" the method
     * should return "dString" as this is the common suffix for those.
     *
     * If no common suffix exists for the argument strings, or if either of them is either
     * empty or null, the method should return an empty string.
     */
    public String getCommonSuffix(String first, String second) {
        String result = "fix me!";
        // your implementation here!
        return result;
    }
}
